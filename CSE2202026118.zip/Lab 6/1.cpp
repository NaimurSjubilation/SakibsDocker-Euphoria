#include<iostream>
using namespace std;
class Box{ public: int height,length,width;
    int PrintVolume(int a,int b,int c) {
        int vol;height=a;length=b;width=c;
        vol=height*length*width; return vol;}};
int main(){
    Box obj; int v,x,y,z;
    cout<<"Enter height,length & width: ";
    cin>>x>>y>>z; v=obj.PrintVolume(x,y,z);
    cout<<"Volume = "<< v ; }
