#include<iostream>
using namespace std;
class card{
string Title,Author;
int NumberOfCopy;
public: void store (string a,string b,int c){
Title=a; Author=b; NumberOfCopy=c;}
void display(){
cout<<"Title: "<<Title<<endl;
 cout<<"Author: "<<Author<<endl;
cout<<"Number Of Copy: "<<NumberOfCopy;}};
    int main(){
card obj;string a,b;int c;
cout<<"Enter Title, Author & Number Of Copy: ";
cin>>a>>b>>c;
 obj.store(a,b,c);obj.display();}


