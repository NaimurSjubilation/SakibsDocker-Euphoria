#include<iostream>
using namespace std;
class prime{int n;
public:void getInput(){
cout<<"\nEnter a Number: ";cin>>n;}
void calculate(){if(n==0||n==1)
  cout<<n<<" is not a Prime ";
else{int i,x=0;for(i=2; i<=n/2; i++)
{if (n%i==0){x=1;}}if(x==0)
 cout<<n<<" is a Prime";
 else cout<<n<<" is not Prime";}}};
int main(){ while(1){
  prime obj; obj.getInput();
    obj.calculate();}}
