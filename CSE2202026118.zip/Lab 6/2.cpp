#include<iostream>
using namespace std;
class person{int ID;
   string Name,Address,BloodGroup,BirthDate;
public:
    void contain(int a,string b,string c,string d,string e){
    ID=a;Name=b;Address=c;BloodGroup=d;BirthDate=e; }
    void FunctionDisplay(){
        cout<<"ID:"<<ID<<endl;
        cout<<"Name:"<<Name<<endl;
        cout<<"Address:"<<Address<<endl;
        cout<<"Blood Group:"<<endl;
        cout<<"Birth Date:"<<BirthDate<<endl;}};
int main(){
    person obj; int a; string b,c,d,e;
    cout<<"ID,Name,Address,Blood Group,Birth Date:\n";
    cin>>a>>b>>c>>d>>e;
    obj.contain(a,b,c,d,e); obj.FunctionDisplay();}

