#include<iostream>
using namespace std;
class Factorial{int F=1,n,i;
 public:void GetInput(){
 cout<<"Enter a Number: ";
  cin>>n;}
  void Fact(){
for(i=1; i<=n; i++){F=F*i;
  }cout<<n<<"!= "<<F;}};
int main (){Factorial obj;
 obj.GetInput();obj.Fact();}
