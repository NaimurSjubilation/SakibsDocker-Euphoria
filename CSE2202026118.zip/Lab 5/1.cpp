#include<iostream>
using namespace std;
float Average(int array[],int n){
    int sum=0,i;float avg;
    for(i=0; i<n; i++)
    sum=sum+array[i];
    avg=((float)sum/n);return avg;}
int main(){
    int n,i;
    cout<<"How many number want input: ";
    cin>>n; int array[n];
    for (i=0; i<n; i++){
        cout<<"Enter a number: ";
        cin>>array[i];}
    cout<<"Average: "<<Average(array,n);}

