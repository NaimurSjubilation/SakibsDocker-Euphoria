#include<iostream>
using namespace std;
void Check(char Ch){
    if(Ch>='0' && Ch<='9')
    cout <<" It's a digit.";
    else if(Ch>='A'&&Ch<='Z')
    cout <<" It's a capital letter.";
    else if(Ch>='a' && Ch<='z')
    cout <<" It's a small letter.";
    else cout <<" It's a spacial character.";}
int main(){
    char Ch;
    cout<<"Enter any Character: ";
    cin>>Ch; Check(Ch);}


