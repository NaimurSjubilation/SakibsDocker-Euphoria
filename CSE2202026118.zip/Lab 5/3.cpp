#include<iostream>
using namespace std;
int M_array(){
    int i,j,r,c,r1,r2,c1,c2;
    cout<<"how many row: ";cin>>r1;
    cout<<"how many column: ";cin>>c1;
    int array[r1][c1];
    for(i=0; i<r1; i++){
    for(j=0; j<c1; j++){
    cout<<"Enter elements: ";
    cin>>array[i][j];}}
    cout<<"how many row: ";cin>>r2;
    cout<<"how many column: ";cin>>c2;
    int b1[r2][c2];
    for(i=0;i<r2; i++){
    for(j=0; j<c2; j++){
    cout<<"Enter elements: ";
    cin>>b1[i][j];}}
    r=(r1>=r2)?r1:r2;c=(c1>=c2)?c1:c2;
    int sum[r][c],a[r][c],b[r][c];
    for(i=0; i<r; i++){
     for(j=0; j<c; j++){
     sum[i][j]=0;a[i][j]=0;b[i][j]=0;}
    }for(i=0; i<r1; i++){
    for(j=0; j<c1; j++){
    a[i][j]=array[i][j];}
    }for(i=0; i<r2; i++){
    for(j=0; j<c2; j++){
     b[i][j]=b1[i][j];}}
    for(i=0; i<r; i++){
    for(j=0; j<c; j++){
    sum[i][j]=a[i][j]+b[i][j];}}
    cout<<"sum: "<<endl;
    for(i=0; i<r; i++){
    for(j=0; j<c; j++){
    cout<<sum[i][j];
    (sum[i][j]<10)?
    cout<<"  ":(sum[i][j]<100)?
    cout<<"  ":(sum[i][j]<1000)?
    cout<<"  ":cout<<" ";}}}
int main(){M_array();}

