#include<iostream>
using namespace std;
int Large(int array[],int n){
    int l=array[0],i;
    for (i=1; i<n; i++){
    if (l<array[i])l=array[i];}
    return l;}
int Short(int array[],int n){
    int s=array[0],i;
    for (i=1; i<n; i++){
   if (s>array[i]) s=array[i];}
    return s;}
int main(){ int n,i,a,b;
    cout<<"How many number want input: ";
    cin>>n; int array[n];
    for (i=0; i<n; i++){
    cout<<"Enter a number: ";
    cin>>array[i];}
    a=Large(array,n);b=Short(array,n);
    cout<<"Largest Number: "<<a<<endl;
    cout<<"Shortest Number: "<<b;}

