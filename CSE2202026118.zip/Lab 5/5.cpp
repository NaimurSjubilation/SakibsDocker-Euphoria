#include<iostream>
using namespace std;
void Fibonacci(){
    int n,x,y,z=0;
    cout<<"Last number of Fibonacci series: ";
    cin>>n;
    cout<<"1st and 2nd element: ";cin>>x>>y;
    cout<<"Fibonacci Series: "<<x<<"  "<<y;
    while(z<=n){
    z=x+y;cout<<" "<<z;
    x=y;y=z;z=x+y;}}
int main(){Fibonacci();}

