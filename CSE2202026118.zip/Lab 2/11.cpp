#include<iostream>
#include<cmath>
using namespace std;
int main(){
//discriminant=d, realPart=r, imaginaryPart=i
    float a,b,c,d,r,i,r1,r2;
cout << "Enter a, b & c : ";
cin >> a >> b >> c ;
if (d == 0){cout << "Roots are real and same \n";
  r1 = -b /(2*a);cout << "X1 = X2 = " << r1 ;}
   else if (d> 0){
  r1 = (-b + sqrt(d))/(2*a);r2= (-b -sqrt(d))/(2*a);
cout<<"Roots are real and different \n";
cout<<"X1 = "<<r1<<"   "<<"X2 = " <<r2;}
  else{r= (float)-b/(2*a);      i= sqrt(-d)/(2*a);
cout<<"Roots are complex and different\n";
cout<<"X1 = " <<r<<"+"<<i<<" i " << "   "
   << "X2 = " <<r<<"-" <<i<<"i " ;}}

