#include<iostream>
using namespace std;
int main(){ while(1){
	int a;
	cout<<"Enter your mark: ";
	cin>>a;
	if(a>100||a<0) cout<<"Invalid\n";
    else if(a>=60) cout<<"First Division\n";
	else if(a>=50) cout<<"Second Division\n";
	else if(a>=40) cout<<"Third Division\n";
	else cout<<"Fail\n";}}
