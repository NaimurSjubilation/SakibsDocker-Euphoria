#include<iostream>
using namespace std;
int main(){ while(1) {
    char a;
    cout<<"Enter a character: ";
    cin>>a;
    if(a>='A' && a<='Z') cout<<a<<" is a capital letter";
    else if(a>='a' && a<='z') cout<<a<<" is a small letter";
    else if(a>='0' && a<='9') cout<<a<<" is a digit\n";
    else cout<<a<<" is a special character"; } }
