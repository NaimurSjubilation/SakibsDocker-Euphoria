#include<iostream>
using namespace std;
int main(){
    int n;
    cin>>n;
    if(n%2==0) cout<<n<<"^2"<<" = "<<n*n;
    else cout<<n<<"^3"<<" = "<<n*n*n;     }
