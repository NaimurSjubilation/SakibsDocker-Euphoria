#include<iostream>
using namespace std;
int main(){
    char a,b;
    cout<<"Enter an alphabet: ";
    cin>>a; b=tolower(a);
    if(b>='a'&& b<='z'){
        switch(b){
        case 'a':
        case 'e':
        case 'i':
        case 'o':
        case 'u':
        cout<<b<<" is a vowel"; break;
        default: cout<<b<<" is a consonant";}
    } else cout<<b<<" is not an alphabet";}

