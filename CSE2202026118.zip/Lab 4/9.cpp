#include<iostream>
using namespace std;
int rev(int n){
int rem,s=0; while(n!=0)
  {rem=n%10;s=rem+s*10;
  n=n/10;} return s;}
  int main(){ int n;
    cout<<"Enter a number: ";
    cin>>n;
cout<<"Reverse number: "<<rev(n);}
