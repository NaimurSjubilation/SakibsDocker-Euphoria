//write a C++ program that take four functions that gets two integer and returns  its sum,subtraction,multiplication,division
#include<iostream>
using namespace std;
int sum(int a,int b){return a+b;}
int sub(int a,int b){return (a-b);}
int multi(int a,int b){return (a*b);}
float divi(int a,int b){return (a/b);}
int main(){int x,y;
	cout<<"Enter two integer:";
	cin>>x>>y;
	cout<<"Sum"<<" = "<<sum(x,y)<<",";
	cout<<"Sub"<<" = "<<sub(x,y)<<",";
	cout<<"Multi"<<" = "<<multi(x,y)<<",";
	cout<<"Div"<<" = "<<divi(x,y)<<".";  }
