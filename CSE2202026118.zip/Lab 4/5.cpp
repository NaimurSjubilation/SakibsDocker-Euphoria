//write a function that gets three numbers and returns medium
#include<iostream>
using namespace std;
int mid(int x,int y,int z){
    if ((y>x&&y<z)||(y<x&&y>z))
        return y;
    else if ((z>x&&z<y)||(z<x&&z>y))
        return z;
    else return x;}
int main(){ int a,b,c;
    cout<<"Enter 3 number: ";
    cin>>a>>b>>c;
    cout<<"medium = "<<mid(a,b,c); }
