#include<iostream>
#include<cmath>
using namespace std;
int Prime(int n){ int i,x=0;
    for (i=2; i<=n/2; i++){
        if (n%i==0){x++;} }
    if(x==0) cout<<n<<" is a Prime ";
    else cout<<n<<" is not  Prime ";}
int main(){ int n;
    cout<<"Enter a number: ";
    cin>>n; if(n==0||n==1)
    cout<<n<<" is not a Prime ";
    else Prime(n);}


