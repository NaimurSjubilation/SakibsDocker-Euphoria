//Write a C++ program that take two functions that gets three integers and return maximum and minimum value
#include<iostream>
using namespace std;
int max(int x,int y,int z){
int m=(x>y&&x>z)?x:(y>z)?y:z;return m;}
int min(int x,int y,int z){
int m=(x<y&&x<z)?x:(y<z)?y:z;return m;}
int main(){ int a,b,c;
cout<<"Enter 3 Numbers: ";
cin>>a>>b>>c;
cout<<"Maximum= "<<max(a,b,c)<<" , ";
cout<<"Minimum= "<<min(a,b,c)<<" ";}

