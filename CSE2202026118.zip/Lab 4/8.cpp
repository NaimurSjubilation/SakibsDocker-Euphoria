//write a function that gets any positive number and returns digital root
#include<iostream>
using namespace std;
int sum(int a){int rem, s=0;
    while(a!=0){ while(a!=0){
    rem=a%10;s=s+rem;a=a/10;}
    if(s>9){a=s;s=0;}} return s;}
int main(){ int n ;
    cout<<"Enter numbers: ";
    cin>>n;
    cout<<"Digital root: "<<sum(n);}

