//write a function that gets length and width of a rectangle and return area
#include<iostream>
using namespace std;
int recArea(){int l,w;
    cout<<"Enter l: "; cin>>l;
    cout<<"Enter W: "; cin>>w;
  return (l*w); }
int main(){ cout<<recArea(); }
