//write a function that gets radius of a circle and return area
#include<iostream>
#define pie 3.1416 //const float pie= 3.1415;
using namespace std;
float area(float a){return (pie*a*a);}
int main(){ float r ;
	cout<<"Enter radius of circle: ";
	cin>>r;
	cout<<"Area of the circle: "<<area(r);}
