//Sum of digits
#include<iostream>
using namespace std;
int main(){
	int n,rem,s=0;
	cout<<"Enter a number: ";
	cin>>n;
	while(n!=0){
    rem=n%10 ; s=s+rem ; n=n/10 ;}
	cout<<"Sum of digits"<<" = "<<s;}
