//nPr=1*(n-0)(n-1)(n-2)(n-3)...(n-(r-1))
#include<iostream>
using namespace std;
int main() {
    int n,r,s=1,i;
    cout<<"Enter the value of n: ";
    cin>>n;
    cout<<"Enter the value of r: ";
    cin>>r;
    for(i=0;i<=r-1;i++) {s=s*(n-i);}
    cout<< n<< "P"<< r <<" = "<<s; }
