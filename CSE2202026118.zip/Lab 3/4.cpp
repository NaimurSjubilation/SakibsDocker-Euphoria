#include<iostream>
using namespace std;
int main(){
	int n,i,s=0;
	cout<<"Enter the series's last element: ";
	cin>>n;
	for(i=1;i<=n;i++) {s= s+(i*i*i);}
	cout<<"Sum from 1^3 to "<<n<<"^3"<<" = " <<s;}
