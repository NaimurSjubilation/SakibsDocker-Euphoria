//counts the number of digits of an number
#include<iostream>
using namespace std;
int main(){
    int n,c=0;
    cout<<"Enter an integer: ";
    cin>>n;
    if(n==0)cout<<"The number of digits= 1";
     else { while(n!=0){ n=n/10; c++;}
    cout<<"Number of digits= "<<c;}}

