//Reverse number
#include<iostream>
using namespace std;
int main(){
	int n,rem,s=0;
	cout<<"Enter a number: ";
	cin>>n;
	while(n!=0){
    rem=n%10; s=s*10+rem;
		n=n/10; }
	cout<<"Reverse numbers: "<<s; }
/**************************************************
when>>>>>>>>> n=123


while(n!=0){//123!=0
		rem=n%10;//rem=123%10=3
		s=s*10+rem;//s=0*10+3=3
		n=n/10; //n=123/10=12   (updated n=12)

when>>>>>>>>>  n=12

while(n!=0){//12!=0
		rem=n%10;//rem=12%10=2
		s=s*10+rem;//s=0*10+2=2
		n=n/10; //n=12/10=1    (updated n=1)


when>>>>>>>>>   n=1
while(n!=0){//1!=0
		rem=n%10;//rem=1%10=1
		s=s*10+rem;//s=0*10+1=1
		n=n/10; //n=1/10=0     (updated n=0)

when>>>>>>>>> n=0
while(n!=0){//0!=0
	loop stop


************************************************/
