//power of a number
#include<iostream>
#include<cmath>
using namespace std;
int main(){
	 int n,p,r;
	cout<<"Enter a number: ";
	cin>>n;
	cout<<"Enter it's power: ";
	cin>>p;        r=pow(n,p);
	cout<<n<<"^"<<p<<" = "<<r; }


/******************************
r= 2,147,483,647 is my limit
******************************/

