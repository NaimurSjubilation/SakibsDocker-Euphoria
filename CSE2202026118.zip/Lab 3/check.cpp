//Reverse number
#include<iostream>
using namespace std;
int main(){
	int n,rem,s=0;
	cout<<"Enter a number: "<<endl;
	cin>>n;
	while(n!=0)  {
    rem=n%10;  s=s*10+rem;
		n=n/10;  }
	cout<<"Reverse numbers"<<" = "<<s;}
