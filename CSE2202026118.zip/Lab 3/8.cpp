//nCr=(nPr/r!)=[1*(n-0)(n-1)(n-2)(n-3)...{n-(r-1)}/r!]
#include<iostream>
using namespace std;
int main() {
    int n,r,s=1,f=1,i;
    cout<<"Enter the value of n: ";
    cin>>n;
    cout<<"Enter the value of r: ";
    cin>>r;
    for(i=1;i<=r;i++){f=f*i;}
    for(i=0;i<=r-1;i++){s=s*(n-i);}
    cout<<n<<"C"<<r <<" = "<<s/f; }






