//To accept 3 numbers from user one by one and display their sum
#include<iostream>
using namespace std;
int main(){
	int a,b,c;
	cout<<"Enter 1st number: ";
	cin>>a;
	cout<<"Enter 2nd number: ";
	cin>>b;
	cout<<"Enter 3rd number: ";
	cin>>c;
	cout<<a<<"+"<<b<<"+"<<c<<"= "<<a+b+c;}
