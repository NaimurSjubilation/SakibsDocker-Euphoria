#include<iostream>
using namespace std;
int main(){
    int n,i;
	cout<<"How many numbers Want to input: ";
	cin>>n;
	int a[n],l=a[0];
	for(i=0;i<n;i++){
    cin>>a[i]; }
	for( i=1; i<n; i++){
    if(l<a[i]) {l= a[i];}}
    cout<<"The largest number is = "<<l;}
