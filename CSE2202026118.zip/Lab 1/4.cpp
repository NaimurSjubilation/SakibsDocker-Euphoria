#include<iostream>
using namespace std;
int main(){
	float a,b;
	cout<<"Enter 2 floating numbers: ";
	cin>>a>>b;
	cout<<a<<" * "<<b<<" = "<<a*b;}
