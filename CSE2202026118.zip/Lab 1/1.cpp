#include<iostream>
using namespace std;
int main(){
	cout<<"This is OOP lab"<<endl;}
