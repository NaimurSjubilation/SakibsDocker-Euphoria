#include<iostream>
using namespace std;
int main(){ int a,b;
	cout<<"Enter dividend & divisor: ";
	cin>>a>>b;
	cout<<"Quotient="<<a/b<<endl;
	cout<<"Reminder="<<a%b<<endl;}
