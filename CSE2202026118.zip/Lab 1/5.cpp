#include<iostream>
using namespace std;
int main(){
	char a;
	cout<<"Enter a character: ";
	cin>>a;
	cout<<int(a)<<" is the \"ASCII\" value of "<<a ;}
