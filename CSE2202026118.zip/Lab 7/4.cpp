#include<iostream>
using namespace std;
class Rect
{
    int x,y,a,b;
public:
    Rect ()
    {
        cout<<"Rectangle's X & Y Cordinant: ";
        cin>>x>>y;
        cout<<"X & Y Cordinant to check: ";
        cin>>a>>b;
    }
    void display()
    {
        if(x==0 || x==a || y==0 || y==b)
        {
            cout<<"Points are on Border.";
        }
        else if(a<x || b<y)
        {
            if (a>0 && y>0)
            {
                cout<<"Points are inside";
            }
            else
            {
                cout<<"Points are outside";
            }
        }
        else
        {
            cout<<"points are out side ";
        }
    }
};
int main()
{
    Rect obj;
    obj.display();
}
