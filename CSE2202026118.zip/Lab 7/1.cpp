#include<iostream>
using namespace std;
class MyClass{
   private: int a;
public: MyClass(int x){a=x;}
    ~MyClass(){
  cout<<"Number was: "<<a;}};
  int main(){
    int x;
    cout<<"Enter a number: ";
    cin>>x; MyClass obj(x);}
