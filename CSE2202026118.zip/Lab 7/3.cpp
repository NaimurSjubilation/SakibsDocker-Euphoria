#include<iostream>
using namespace std;
class ClN{
    int n,i,CN,d,a;int array[];
public:ClN(){
cout<<"How Many Number Want Enter: ";
 cin>>n;
for(i=0; i<n; i++){
cout<<"Enter a Number: ";
cin>>array[i];}}
void Operation(){
CN=array[0]; d=100-array[0];
if (d<0){d=d*(-1);}
for (i=1; i<n; i++){
 a=100-array[i];
if (a<0){a=a*(-1);}
 if (a<=d){d=a;
 CN=array[i];}}}
    ~ClN(){cout<<"Nearest: "<<CN<<endl;
cout<<"Distance: "<<d<<endl;}};
int main(){ClN obj; obj.Operation();}
