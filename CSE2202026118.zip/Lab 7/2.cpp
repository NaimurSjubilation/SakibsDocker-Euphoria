#include <iostream>
using namespace std;
class Bank{string D_Name;
    int Acc_Num,Balance=0,Deposit,W_Amount;
public: AssignValues(){cout<<"Name :";
cin.ignore();getline(cin,D_Name);
cout<<"Account Number:";
cin>>Acc_Num;}
Deposit_Amount(){cout<<"Deposit Amount: ";
cin>>Deposit; Balance=Balance+Deposit;
cout<<"Current Balance: "<<Balance<<endl;}
  Widthdrow(){
cout<<"Withdraw amount: "; cin>>W_Amount;
if(Balance>=W_Amount){
 Balance=Balance-W_Amount;
cout<<W_Amount<<" Taka Withdrawal Successful.";}
else cout<<"Insufficient Amount";}
Info(){cout<<"\nDepositor Name    : "<<D_Name;
cout<<"\nAccount Number    : "<<Acc_Num;
cout<<"\nAvailable Balance : "<<Balance<<endl;}};
menu(){cout<<"0. Exit"<<"\t "
<<"1.Name and Account Number\n";
cout<<"2. Deposit"<<"\t"<<"3. Withdraw\n ";}
int main(){menu();Bank obj;
 while(1){int x;
cout<<"Enter your choice:";
cin>>x;switch(x){
   case 0:exit(0); break;
   case 1:obj.AssignValues(); break;
   case 2:obj.Deposit_Amount();break;
   case 3:obj.Widthdrow();obj.Info();break;
   default: cout<<"Invalid Choice" ;}}}
